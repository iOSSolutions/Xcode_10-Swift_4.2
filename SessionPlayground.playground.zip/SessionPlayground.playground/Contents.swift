import UIKit


//Boolean Toggling
var someBoolValue = true
someBoolValue.toggle()






//Warning and Error Diagnostic Directives

#warning("Note this code needs to be refactored ")

//if !someBoolValue {
//    #error("This boolean value must be toggled")
//}





//List allCases in an enum using CaseIterable
enum Colors : CaseIterable {
    case red,green,blue
}
print(Colors.allCases.count)
for color in Colors.allCases{
    print("My favourite color is \(color)")
}



//allSatisfy : Checking Sequence Elements match a condition
let examScores = [40,45,36,50]
let passed = examScores.allSatisfy({$0 > 35})
passed




//Random numbers generation and Shuffling
let randomInt = Int.random(in: 1..<5)
let randomFloat = Float.random(in: 1..<10)
let randomDouble = Double.random(in: 1...100)
let randomCGFloat = CGFloat.random(in: 1...1000)
let randomBool = Bool.random()

var numbers = ["one","two","three","four","five"]
//numbers.shuffle()
//let shuffledNumbers = numbers.shuffled()
//shuffledNumbers
//numbers
//In-place collection element Removal
numbers.removeAll{$0.hasPrefix("t")}
numbers

